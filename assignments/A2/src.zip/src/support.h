
void error(const char* message);

